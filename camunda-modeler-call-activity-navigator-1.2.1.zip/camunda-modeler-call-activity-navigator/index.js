module.exports = {
  name: 'Call Activity Navigator',
  script: './dist/client.js'
};
